var myObj = {
    name:"张三",
    age:18
}

export default {myObj}